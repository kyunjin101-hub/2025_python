import tkinter as tk

class Person:
    def __init__(self,name: str):
        self.name = name

class HobbyPerson(Person):
    def __init__(self,name: str):
        super().__init__(name)
        self.hobbies = []

    def add_hobby(self,hobby: str):
        if hobby not in self.hobbies:
            self.hobbies.append(hobby)

    def clear_hobbies(self):
        self.hobbies.clear()

root = tk.Tk()
root.title("문제 2")
root.geometry("380x260")

person = HobbyPerson("김덕성")
title = tk.Label(root,text=f"이름: {person.name}")
title.pack(pady=6)

frm = tk.Frame(root)
title.pack(pady=6, anchor="center")

var_ga = tk.IntVar(value="0")
var_re = tk.IntVar(value="0")
var_ex = tk.IntVar(value="0")

rd1 = tk.Radiobutton(frm, text="게임", value=1,variable=var_ga)
rd2 = tk.Radiobutton(frm, text="독서",value=2,variable=var_re)
rd3 = tk.Radiobutton(frm, text="운동",value=3,variable=var_ex)

rd1.grid(row=0, column=0,padx=8,pady=4,sticky="w")
rd2.grid(row=0, column=1,padx=8,pady=4,sticky="w")
rd3.grid(row=0, column=2,padx=8,pady=4,sticky="w")

result = tk.StringVar(value="취미를 선택하고 [등록하기]를 누르세요.")
nb = tk.Label(root,textvariable=result,wraplength=340, justify="left")
nb.pack(pady=8)

def register():
    person.clear_hobbies()
    if var_ga.get(): person.add_hobby("게임")
    if var_re.get(): person.add_hobby("독서")
    if var_ex.get(): person.add_hobby("운동")

    if person.hobbies:
        result.set(f"현재 취미: {", "}.join(person.hobbies)")
    else:
        result.set("선택된 취미가 없습니다.")

def reset():
    var_ga.set(0)
    var_re.set(0)
    var_ex.set(0)
    person.clear_hobbies()
    result.set("모든 선택을 해제했습니다.")


frm_btn = tk.Frame(root)
frm_btn.pack(pady=6)

tk.Button(frm_btn, text="등록하기", width=12, command=register).pack(side="left",padx=8)
tk.Button(frm_btn, text="초기화", width=12, command=reset).pack(side="left",padx=8)

root.mainloop()