import pygame

pygame.init()

WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Step 10 - Collision")

clock = pygame.time.Clock() 

class Player(pygame.sprite.Sprite):
  def __init__(self):
    super().__init__()
    self.image = pygame.image.load("dukbird.png")        
    self.image = pygame.transform.scale(self.image, (50, 50))  
    self.rect = self.image.get_rect()
    self.rect.center = (WIDTH // 2, HEIGHT // 2)
    self.speed = 3

  def update(self): 
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
      self.rect.x -= self.speed
    if keys[pygame.K_RIGHT]:
      self.rect.x += self.speed
    if keys[pygame.K_UP]:
      self.rect.y -= self.speed
    if keys[pygame.K_DOWN]:
      self.rect.y += self.speed

    self.rect.clamp_ip(screen.get_rect())

all_sprites = pygame.sprite.Group()

player = Player()
all_sprites.add(player)

running = True
game_over = False       

while running:
  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      running = False

  if not game_over:
    all_sprites.update()     

  screen.fill((170, 200, 255))  
  pygame.draw.rect(screen, (80, 170, 80), (0, HEIGHT - 60, WIDTH, 60))  


  pygame.draw.line(screen, (0, 0, 0), (300, 300), (500, 300), 5)

  font = pygame.font.SysFont(None, 24)

  if game_over:
    over_text = font.render("GAME OVER", True, (255, 0, 0))
    over_x = (WIDTH - over_text.get_width()) // 2 
    over_y = (HEIGHT - over_text.get_height()) // 2 
    screen.blit(over_text, (over_x, over_y))

  pygame.display.flip()
  clock.tick(60)
pygame.quit()